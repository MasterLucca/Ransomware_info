import requests
import pandas as pd

def obter_dados_ransomware(ano, mes):
    # URL da API para obter incidentes de ransomware
    url = f"https://api.ransomware.live/victims/{ano}/{mes}"
    
    # Fazendo a requisição GET
    response = requests.get(url, headers={"accept": "application/json"})
    
    # Verificando se a requisição foi bem-sucedida
    if response.status_code == 200:
        return response.json()  # Retorna os dados em formato JSON
    else:
        print(f"Erro ao obter dados: {response.status_code} - {response.text}")
        return None

def salvar_em_excel(dados, ano, mes):
    # Convertendo os dados em um DataFrame do pandas
    df = pd.DataFrame(dados)
    
    # Salvando o DataFrame em um arquivo Excel
    nome_arquivo = f"ransomware_brasil_{ano}_{mes}.xlsx"
    df.to_excel(nome_arquivo, index=False)
    print(f"Dados salvos em {nome_arquivo}")

def main():
    ano = input("Digite o ano (ex: 2023): ")
    mes = input("Digite o mês (ex: 06): ")
    
    # Obtendo dados de ransomware
    dados = obter_dados_ransomware(ano, mes)
    
    if dados:
        # Salvando os dados em um arquivo Excel
        salvar_em_excel(dados, ano, mes)

if __name__ == "__main__":
    main()

